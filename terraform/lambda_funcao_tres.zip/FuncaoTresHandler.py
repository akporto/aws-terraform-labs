import json
import os
import boto3
from datetime import datetime

dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    print("Processando requisição para atualizar item")

    table_name = os.environ['DYNAMODB_TABLE_NAME']
    table = dynamodb.Table(table_name)

    try:
        body = json.loads(event['body'])

        # Validação de status
        if 'status' in body and body['status'] not in ['TODO', 'DONE']:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'success': False, 'message': 'Status deve ser TODO ou DONE'})
            }

        # Validação de campos obrigatórios
        if not all(key in body for key in ['pk', 'itemId']):
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'success': False, 'message': 'pk e itemId são obrigatórios'})
            }

        formatted_pk = f"LIST#{body['pk']}"
        formatted_sk = f"ITEM#{body['itemId']}"

        # Verifica existência do item
        existing_item = table.get_item(Key={'PK': formatted_pk, 'SK': formatted_sk}).get('Item')
        if not existing_item:
            return {
                'statusCode': 404,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'success': False, 'message': 'Item não encontrado'})
            }

        # Prepara atualização
        update_expr = []
        expr_values = {}
        expr_names = {}

        if 'name' in body:
            update_expr.append("#nm = :name")
            expr_values[':name'] = body['name']
            expr_names['#nm'] = 'name'

        if 'date' in body:
            update_expr.append("#dt = :date")
            expr_values[':date'] = body['date']
            expr_names['#dt'] = 'date'

        if 'status' in body:
            update_expr.append("#st = :status")
            expr_values[':status'] = body['status']
            expr_names['#st'] = 'status'

        if not update_expr:
            return {
                'statusCode': 400,
                'headers': {'Content-Type': 'application/json'},
                'body': json.dumps({'success': False, 'message': 'Nenhum campo válido para atualização'})
            }

        # Adiciona campo updatedAt para rastrear a última atualização
        update_expr.append("#updatedAt = :updatedAt")
        expr_values[':updatedAt'] = datetime.now().isoformat()
        expr_names['#updatedAt'] = 'updatedAt'

        # Executa a atualização
        response = table.update_item(
            Key={'PK': formatted_pk, 'SK': formatted_sk},
            UpdateExpression="SET " + ", ".join(update_expr),
            ExpressionAttributeValues=expr_values,
            ExpressionAttributeNames=expr_names,
            ReturnValues='ALL_NEW'
        )

        # Retorna o item completo atualizado
        updated_item = response['Attributes']
        return {
            'statusCode': 200,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({
                'success': True,
                'message': 'Item atualizado com sucesso',
                'item': updated_item
            }, ensure_ascii=False)
        }

    except Exception as e:
        print(f"Erro: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {'Content-Type': 'application/json'},
            'body': json.dumps({'success': False, 'message': f'Erro interno: {str(e)}'})
        }